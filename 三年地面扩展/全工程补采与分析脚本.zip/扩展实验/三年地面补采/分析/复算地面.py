"""Combine verified baseline city-hours and newly ingested PM2.5 / NO2 daily measurements.

Python 3.12. Paths under the project are recorded relative to its root. Existing daily
observations are immutable. A new source verification runs before each snapshot.
"""
import argparse
import csv
import gzip
import hashlib
import json
import re
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from extend_ground import make_roster, sha
from ground import YRD

BASE = ROOT / "扩展实验/跨期分析"
DATES = pd.date_range("2023-01-01", "2025-12-31")
COLS = ["PM2.5", "NO2"]
CITY_COLS = ["time", "city", *COLS, "n_PM2.5", "n_NO2"]
DATE_NAME = re.compile(r"china_sites_(\d{8})\.csv(?:\.gz)?$")


def open_raw(path):
    return gzip.open(path, "rt", encoding="utf-8-sig", newline="") if path.suffix == ".gz" else path.open(encoding="utf-8-sig", newline="")


def sources(folders):
    ledger = pd.read_csv(BASE / "地面文件校验.csv", parse_dates=["date"])
    current = {}
    for row in ledger.itertuples():
        path = ROOT / row.path
        if path.stat().st_size != row.bytes or sha(path) != row.sha256:
            raise ValueError(f"旧原始文件校验失败 {path}")
        current[row.date] = (path, row.sha256)
    old = set(current)
    for folder in folders:
        for path in sorted(folder.glob("china_sites_*.csv*")):
            match = DATE_NAME.fullmatch(path.name)
            if not match:
                continue
            date = pd.to_datetime(match[1], format="%Y%m%d")
            if date not in DATES:
                continue
            prior = current.get(date)
            if prior and prior[0] == path:
                continue
            digest = sha(path)
            if prior and digest != prior[1]:
                with open_raw(prior[0]) as a, open_raw(path) as b:
                    if a.read() != b.read():
                        raise ValueError(f"同日两种内容，请先核查 {date} {prior[0]} {path}")
            if not prior:
                current[date] = (path, digest)
    return current, old


def roster(current, new_dates):
    old = pd.read_csv(BASE / "站点匹配明细.csv")
    active = set(old.station)
    for day in new_dates:
        with open_raw(current[day][0]) as f:
            header = next(csv.reader(f))
        if header[:3] != ["date", "hour", "type"] or len(header) != len(set(header)):
            raise ValueError(f"站点表头异常 {day}")
        active.update(header[3:])
    merged = make_roster(active)
    before = old.set_index("station").city.sort_index()
    after = merged.set_index("station").city.reindex(before.index)
    pd.testing.assert_series_equal(before, after)
    return merged


def city_hour(path, date, mapping):
    data = pd.read_csv(path)
    if (data.empty or not data.date.astype(str).eq(date.strftime('%Y%m%d')).all()
            or not data.hour.isin(range(24)).all() or data.duplicated(["hour", "type"]).any()):
        raise ValueError(f"日文件完整性或小时键异常 {path}")
    stations = mapping.index.intersection(data.columns, sort=False)
    cities = mapping.loc[stations]
    times = pd.date_range(date, periods=24, freq="h").rename("time")
    output = {}
    raw_n = []
    for name in COLS:
        values = data.loc[data.type == name].set_index("hour")[stations].reindex(range(24))
        values = values.where(np.isfinite(values) & (values >= 0))
        groups = values.T.groupby(cities.rename("city"), sort=True)
        means = groups.mean().T.set_axis(times)
        counts = groups.count().T.set_axis(times)
        output[name] = means.stack(future_stack=True)
        output["n_" + name] = counts.stack(future_stack=True)
        raw_n.append(int(counts.to_numpy().sum()))
    hourly = pd.DataFrame(output).dropna(subset=COLS, how="all").reset_index()[CITY_COLS]
    if hourly.empty:
        raise ValueError(f"已归并站点无可分析观测 {path}")
    qc = {"source_rows":len(data), "mapped_station_columns":len(stations), "PM25_station_values":raw_n[0],
          "NO2_station_values":raw_n[1], "city_hours":len(hourly),
          "pm25_reporting_hours":int(data.loc[data.type.eq("PM2.5"), "hour"].nunique()),
          "no2_reporting_hours":int(data.loc[data.type.eq("NO2"), "hour"].nunique())}
    return hourly, qc


def cached_city_hour(path, day, digest, mapping, cache):
    # Bind the cache to raw bytes and the mapping of stations actually present.
    with open_raw(path) as f:
        stations = next(csv.reader(f))[3:]
    lookup = mapping.reindex(stations).fillna("").to_csv(header=False).encode()
    key = hashlib.sha256(lookup).hexdigest()[:16]
    file = cache / f"{day:%Y%m%d}_{digest[:16]}_{key}.parquet"
    qcfile = file.with_suffix(".json")
    if file.exists() and qcfile.exists():
        return pd.read_parquet(file), json.loads(qcfile.read_text())
    hour, qc = city_hour(path, day, mapping)
    # All cache writes occur in the same parent filesystem; install only finished parts.
    with tempfile.TemporaryDirectory(dir=cache) as temp:
        local = Path(temp)/file.name
        hour.to_parquet(local,index=False)
        meta = local.with_suffix(".json")
        meta.write_text(json.dumps(qc))
        local.replace(file)
        meta.replace(qcfile)
    return hour, qc


def aggregate_day(hourly):
    days = hourly.groupby(["city", hourly.time.dt.normalize().rename("date")]).agg(
        pm25=("PM2.5", "mean"), valid_hours=("PM2.5", "count"), no2=("NO2", "mean")).reset_index()
    days["qualified"] = days.valid_hours.ge(20)
    days["heavy"] = days.qualified & days.pm25.gt(150)
    days["yrd41"] = days.city.isin(YRD)
    return days


def results(days, out):
    high = days[days.heavy].sort_values(["city", "date"]).copy()
    high["event"] = (high.city.ne(high.city.shift()) | high.date.diff().ne(pd.Timedelta(days=1))).cumsum()
    events = high.groupby(["city", "event"]).agg(start=("date", "min"), end=("date", "max"),
        days=("date","size"), peak_PM25=("pm25","max")).reset_index()
    covered = pd.MultiIndex.from_frame(days.loc[days.qualified, ["city", "date"]])
    for side, step in [("start",-1), ("end",1)]:
        events[side + "_unknown"] = ~pd.MultiIndex.from_arrays([events.city, events[side] + pd.Timedelta(days=step)]).isin(covered)
    events["yrd41"] = events.city.isin(YRD)
    events.to_csv(out/"全国重污染过程.csv", index=False)
    calendar = pd.read_csv(ROOT/"多源数据与实验/data/cleaned/spring_calendar.csv", parse_dates=["date"])
    yrd = days[days.yrd41 & days.qualified]
    windows = []
    for year in [2023, 2024, 2025]:
        hol = calendar[calendar.date.dt.year.eq(year)&calendar.spring_break]
        for label, lo, hi in [("节前7日",hol.date.min()-pd.Timedelta(days=7),hol.date.min()-pd.Timedelta(days=1)),
                              ("春节假期",hol.date.min(),hol.date.max()),
                              ("节后7日",hol.date.max()+pd.Timedelta(days=1),hol.date.max()+pd.Timedelta(days=7))]:
            g = yrd[yrd.date.between(lo,hi)]
            windows.append([year,label,lo,hi,(hi-lo).days+1,g.date.nunique(),len(g),g.pm25.mean(),g.heavy.sum() if len(g) else np.nan])
    pd.DataFrame(windows, columns=["年","窗口","起","止","应有日期数","实有日期数","长三角合格城市日","平均PM25","重污染城市日"]).to_csv(out/"春节比较.csv",index=False)
    rows = []
    for region, subset in [("全国",days),("长三角41城",days[days.yrd41]),("南京",days[days.city.eq("南京")])]:
        for year in [0, 2023, 2024, 2025]:
            g = subset[subset.qualified]
            if year:
                g = g[g.date.dt.year.eq(year)]
            rows.append([region,year or "合计",g.date.nunique(),g.city.nunique(),len(g),g.heavy.sum(),g[g.heavy].date.nunique(),g.pm25.max()])
    pd.DataFrame(rows,columns=["范围","时期","有效日期数","城市数","合格城市日","超阈值城市日","超阈值实际日期数","最高城市日均PM25"]).to_csv(out/"分年地区汇总.csv",index=False)
    return events


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--raw-dir",type=Path,action="append",default=[])
    parser.add_argument("--output",type=Path)
    parser.add_argument("--precompute",action="store_true",help="只缓存在本次启动时已经校验并且完整落盘的新增站点日")
    args=parser.parse_args()
    folders = [ROOT/"data/raw/air", ROOT/"多源数据与实验/data/raw/ground", *args.raw_dir]
    current, old = sources([p.resolve() for p in folders])
    new_dates = sorted(set(current) - old)
    cache=HERE/"逐日城市小时缓存"
    cache.mkdir(exist_ok=True)
    ro = roster(current, new_dates)
    mapping = ro.dropna(subset=["city"]).set_index("station").city
    if args.precompute:
        for day in new_dates:
            path, digest = current[day]
            cached_city_hour(path, day, digest, mapping, cache)
        print(f"本次快照命中或新算 {len(new_dates)} 个新增日",flush=True)
        return
    if args.output is None:
        parser.error("生成结果需 --output")
    out = args.output.resolve()
    if out.exists():
        raise ValueError(f"请选择新的结果目录 {out}")
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".计算中-",dir=out.parent) as tmp:
        stage = Path(tmp)/"snapshot"
        stage.mkdir()
        ro.to_csv(stage/"站号匹配.csv",index=False)
        daily = [pd.read_parquet(BASE/"全国城市日.parquet")]
        if set(daily[0].date.unique()) != old:
            raise ValueError("旧城市日日期与旧校验清单不一致")
        ledger=[]
        checks=[]
        ref_path=BASE/"全国城市小时.parquet"
        schema=pq.read_schema(ref_path).remove_metadata()
        with pq.ParquetWriter(stage/"全国城市小时.parquet",schema,compression="zstd") as writer:
            for batch in pq.ParquetFile(ref_path).iter_batches(batch_size=100000):
                writer.write_batch(batch)
            for i,day in enumerate(new_dates, 1):
                hourly,qc = cached_city_hour(current[day][0],day,current[day][1],mapping,cache)
                daily.append(aggregate_day(hourly))
                writer.write_table(pa.Table.from_pandas(hourly,schema=schema,preserve_index=False))
                checks.append(dict(date=day,**qc))
                if i%60==0:
                    print(f"已分析新增日期 {i}/{len(new_dates)}",flush=True)
        for day,(path,digest) in sorted(current.items()):
            ledger.append([day,path.relative_to(ROOT) if path.is_relative_to(ROOT) else path,path.stat().st_size,digest,"旧城市小时" if day in old else "新增站点原档重算"])
        pd.DataFrame(ledger,columns=["date","path","bytes","sha256","usage"]).to_csv(stage/"分析输入逐日清单.csv",index=False)
        pd.DataFrame(checks,columns=["date","source_rows","mapped_station_columns","PM25_station_values","NO2_station_values","city_hours","pm25_reporting_hours","no2_reporting_hours"]).to_csv(stage/"新增逐日质量.csv",index=False)
        days=pd.concat(daily, ignore_index=True).sort_values(["city","date"])
        if days.duplicated(["city","date"]).any():
            raise ValueError("城市日重复")
        days.to_parquet(stage/"全国城市日.parquet",index=False)
        events=results(days,stage)
        yrd = days[days.yrd41]
        coverage = yrd.groupby("date").agg(长三角有任意污染物城市数=("city","nunique"),
            长三角合格城市数=("qualified","sum"), 长三角超阈值城市数=("heavy","sum")).reindex(DATES)
        coverage.index.name = "date"
        coverage.insert(0,"全国站点档实际用于分析",coverage.index.isin(current))
        coverage.to_csv(stage/"三年逐日覆盖与区域共现.csv")
        exposure = []
        for year in [2023, 2024, 2025]:
            for label, months in [("全年", list(range(1,13))), ("6月", [6]), ("10–11月",[10,11])]:
                part = coverage[(coverage.index.year==year) & coverage.index.month.isin(months)]
                exposure.append([year,label,len(part),int(part.iloc[:,0].sum()),int(part["长三角合格城市数"].sum()),
                                 int(part["长三角超阈值城市数"].sum()),int((part["长三角超阈值城市数"]>0).sum()),
                                 int((part["长三角超阈值城市数"]>=2).sum())])
        pd.DataFrame(exposure, columns=["年","观测窗口","日历天数","实际站点档天数","合格城市日","超阈值城市日",
                                      "至少1城超阈值天数","至少2城同日超阈值天数"]).to_csv(stage/"长三角季节与同日超阈值.csv",index=False)
        hourfile = pq.ParquetFile(stage/"全国城市小时.parquet")
        totals = np.zeros(2, dtype=np.int64)
        for batch in hourfile.iter_batches(columns=["n_PM2.5","n_NO2"]):
            totals += np.array([batch.column(i).to_numpy().sum() for i in range(2)], dtype=np.int64)
        satellite_dirs = (ROOT/"多源数据与实验/data/raw/s5p", HERE.parent/"卫星扩月/区域日窗")
        satellite = {pd.Timestamp(p.stem) for folder in satellite_dirs for p in folder.glob("????????.npz")}
        status = dict(used_days=len(current),new_site_days=len(new_dates),missing_site_days=len(DATES)-len(current),
            ground_unique_raw_bytes=sum(p.stat().st_size for p,h in current.values()), source_digests=len({h for p,h in current.values()}),
            actual_city_hour_rows=hourfile.metadata.num_rows, pm25_station_hour_values=int(totals[0]), no2_station_hour_values=int(totals[1]),
            dates_with_qualified_pm25=int(days[days.qualified].date.nunique()), city_days_qualified=int(days.qualified.sum()),
            national_episodes=len(events), yrd_episodes=int(events.yrd41.sum()),
            nanjing_episodes=int(events.city.eq("南京").sum()), q1_new_ground_Jun_Oct_Nov_dates=sum(d.month in [6,10,11] for d in new_dates),
            q2_L3_windows=len(satellite), q2_new_ground_dates_with_L3=len(set(new_dates)&satellite))
        (stage/"使用状态.json").write_text(json.dumps(status,indent=2,ensure_ascii=False))
        stage.rename(out)
        print(json.dumps(status,ensure_ascii=False),flush=True)


if __name__ == "__main__":
    main()
