"""Independently trace the published Q1–Q3 samples to observations and predictions."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def inspect(ground, fusion, satellite):
    data=fusion/'data/integrated'
    results=fusion/'results'
    q1rec=json.loads((fusion/'运行输入.json').read_text())
    assert q1rec['ground_hours_sha256']==digest(ground/'全国城市小时.parquet')
    assert q1rec['episode_sha256']==digest(ground/'全国重污染过程.csv')
    pairs=pd.read_csv(data/'fire_wind_sector_contrasts.csv.gz')
    keys=['time','lat_grid','lon_grid']
    assert not pairs.duplicated(keys+['lag']).any()
    events=pairs.pivot(index=keys,columns='lag',values='delta_pm25')[[0,6,12,24,48]].dropna()
    farm=pairs.set_index(keys).query('lag==0').n_farmland.reindex(events.index).ge(2)
    summary=pd.read_csv(results/'火点相同锚点对照.csv')
    for label,subset in [('全部共同锚点',events),('含两个已绘制农田格的共同锚点',events.loc[farm])]:
        reported=summary[summary.scope==label].set_index('lag').reindex(subset.columns)
        assert (reported.grids_hours==len(subset)).all() and (reported.anchor_days==subset.index.get_level_values('time').str[:10].nunique()).all()
        np.testing.assert_allclose(reported.mean_delta,subset.mean(),atol=1e-5,rtol=0)
    city_days=pd.read_parquet(ground/'全国城市日.parquet')
    heavy=city_days.query('valid_hours>=20 & pm25>150 & yrd41').sort_values(['city','date'])
    raw=pd.read_csv(ground/'全国重污染过程.csv',parse_dates=['start','end']).query('yrd41')
    flat=[(r.city,day) for r in raw.itertuples() for day in pd.date_range(r.start,r.end)]
    observed=set(heavy[['city','date']].itertuples(index=False,name=None))
    assert len(flat)==len(observed) and set(flat)==observed
    counts=pd.read_csv(results/'episode_cluster.csv')
    assert set(zip(counts.city,counts.start))==set(zip(raw.city,raw.start.dt.strftime('%Y-%m-%d')))
    rec=dict(common_events=len(events),mapped_farmland_events=int(farm.sum()),mean_12h=events[12].mean(),
             heavy_yrd_city_days=len(heavy),heavy_dates=heavy.date.nunique(),yrd_city_episodes=len(raw),
             complete_cluster_n=int(counts.cluster.notna().sum()),nanjing_episodes=int(raw.city.eq('南京').sum()))
    if satellite:
        source=json.loads((satellite/'运行记录.json').read_text())
        input_table=(ground/'全国城市小时.parquet' if source.get('ground_only_input') else data/'yrd_ground_era5_hour.parquet')
        assert source['air_sha256']==digest(input_table)
        sat=pd.read_parquet(satellite/'模型实际使用的城市小时.parquet')
        real=pd.read_parquet(data/'yrd_ground_era5_hour.parquet',columns=['city','time','no2','ws_ms','blh_m'])
        compare=sat.merge(real,on=['city','time'],suffixes=('_sat','_fusion'),how='left',validate='many_to_one')
        for name in ['no2','ws_ms','blh_m']:
            np.testing.assert_allclose(compare[name+'_sat'],compare[name+'_fusion'],rtol=1e-9)
        pred=pd.read_parquet(satellite/'留出月预测明细.parquet')
        stats=pd.read_csv(satellite/'滚动留出月指标.csv')
        assert not pred.duplicated(['month','date','city','model']).any()
        for r in stats.itertuples():
            group=pred[(pred.month==r.month)&(pred.model==r.model)]
            assert group.date.min()>pd.Timestamp(r.train_last)
            assert len(sat[sat.month < r.month])==r.n_train and len(group)==r.n_test
            np.testing.assert_allclose((group.prediction-group.no2).abs().mean(),r.mae,rtol=1e-9)
        masses=[]
        for receipt in (satellite.parent/'逐日凭证').glob('*.json'):
            r=json.loads(receipt.read_text()); path=satellite.parent/'区域日窗'/(r['day']+'.npz')
            assert digest(path)==r['regional_sha256'] and path.stat().st_size==r['regional_bytes']
            masses.append(path.stat().st_size)
        rec.update(new_satellite_receipts=len(masses),new_satellite_region_bytes=sum(masses),model_city_days=len(sat),
                   heldout_months=stats.month.nunique(),metrics_checked=len(stats))
    return rec


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ['ground','fusion']:parser.add_argument(name,type=Path)
    parser.add_argument('--satellite',type=Path)
    a=parser.parse_args()
    r=inspect(a.ground,a.fusion,a.satellite)
    out=HERE/(a.ground.name+('三问复核.json' if a.satellite else '火点与过程复核.json'))
    out.write_text(json.dumps(r,ensure_ascii=False,indent=2));print(out.read_text())
