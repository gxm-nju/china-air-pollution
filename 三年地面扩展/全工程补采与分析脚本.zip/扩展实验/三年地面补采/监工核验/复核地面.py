"""From the final inventory: verify raw hashes, consumed fields, city-hour counts, and sample means."""
import argparse
import csv
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SPECIES = [b"PM2.5", b"NO2"]
CITIES = ["南京", "阜阳", "上海"]


def inspect_day(entry, mapped, sample):
    path = ROOT / entry["path"]
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert path.stat().st_size == int(entry["bytes"]) and digest == entry["sha256"], path
    raw = gzip.decompress(data) if path.suffix == ".gz" else data
    rows = iter(raw.splitlines(keepends=True))
    header = next(rows).decode("utf-8-sig").strip().split(",")
    assert header[:3] == ["date", "hour", "type"] and len(set(header)) == len(header)
    cols = [(i, mapped[key]) for i,key in enumerate(header[3:]) if key in mapped]
    stamp = entry["date"].replace("-","").encode()
    count = Counter()
    seen = set()
    sums = defaultdict(list)
    for line in rows:
        if not line.strip():
            continue
        day, hour, pol, values = line.rstrip(b"\r\n").split(b",", 3)
        assert day == stamp and 0 <= int(hour) <= 23 and (hour, pol) not in seen, (day,hour,pol)
        seen.add((hour, pol))
        if pol not in SPECIES:
            continue
        cells = values.split(b",")
        assert len(cells) == len(header)-3
        species = pol.decode()
        count["rows"] += 1
        count["row_bytes"] += len(line)
        for i,city in cols:
            cell = cells[i]
            if not cell:
                continue
            val = float(cell)
            if not (math.isfinite(val) and val >= 0):
                continue
            count[species] += 1
            count['number_bytes'] += len(cell)
            if sample and int(hour)==12 and city in CITIES:
                sums[city,species].append(val)
    assert count["rows"] > 0
    checks = {(city, species): sum(v)/len(v) for (city, species),v in sums.items()}
    return {"date":entry["date"],"usage":entry["usage"],"bytes":len(data),"sha256":digest,
            **{field:count[field] for field in ["rows","row_bytes","number_bytes","PM2.5","NO2"]}}, checks


def main():
    p=argparse.ArgumentParser(); p.add_argument("snapshot",type=Path); args=p.parse_args()
    snap=args.snapshot.resolve()
    ledger=list(csv.DictReader((snap/"分析输入逐日清单.csv").open()))
    assert len({r['date'] for r in ledger})==len(ledger)
    assert len({r['sha256'] for r in ledger})==len(ledger)
    old_qc=pd.read_csv(ROOT/"扩展实验/跨期分析/逐日质量.csv")
    old=set(old_qc.date)
    mapping={r["station"]:r["city"] for r in csv.DictReader((snap/"站号匹配.csv").open()) if r["city"]}
    by_month=defaultdict(list)
    for row in ledger:
        by_month[row["date"][:7]].append(row["date"])
    dates={sorted(v)[len(v)//2] for v in by_month.values()}
    audited=[]; samples={}
    for row in ledger:
        info, checks=inspect_day(row,mapping,row["date"] in dates)
        audited.append(info)
        for (city, species),val in checks.items():
            samples[(row["date"],city,species)]=val
    daily=pd.DataFrame(audited).set_index("date")
    sums=Counter(); observed={}
    for batch in pq.ParquetFile(snap/"全国城市小时.parquet").iter_batches(batch_size=120000):
        h=batch.to_pandas()
        h['date']=h.time.dt.strftime('%Y-%m-%d')
        for day,r in h.groupby("date")[["n_PM2.5","n_NO2"]].sum().iterrows():
            for pol in SPECIES:
                name=pol.decode()
                sums[day,name]+=int(r["n_"+name])
        probe=h[h.date.isin(dates) & h.city.isin(CITIES) & h.time.dt.hour.eq(12)]
        for row in probe.to_dict('records'):
            for pol in SPECIES:
                name=pol.decode();val=row[name]
                if pd.notna(val):
                    observed[row["date"],row["city"],name]=val
    for date,row in daily.iterrows():
        for pol in SPECIES:
            name=pol.decode()
            assert sums.get((date,name),0)==int(row[name]),(date,name)
    assert set(observed)==set(samples) and all(math.isclose(samples[k],v,abs_tol=1e-7) for k,v in observed.items())
    qc=pd.read_csv(snap/"新增逐日质量.csv").set_index("date")
    new=daily[~daily.index.isin(old)]
    assert set(qc.index)==set(new.index)
    for date,row in new.iterrows():
        assert row["PM2.5"]==qc.at[date,"PM25_station_values"] and row["NO2"]==qc.at[date,"NO2_station_values"]
    columns=["bytes","rows","row_bytes","number_bytes","PM2.5","NO2"]
    rec={"completed_local":datetime.now().astimezone().isoformat(),"snapshot":str(snap.relative_to(ROOT)),
         "source_days":len(daily),"old_days":len(old),"new_days":len(new),"missing_days":1096-len(daily),
         "all":{k:int(v) for k,v in daily[columns].sum().items()},
         "new":{k:int(v) for k,v in new[columns].sum().items()},
         "sample_day_count":len(dates),"sample_means_checked":len(samples),
         "method":"逐日文件哈希核对；仅精确PM2.5和NO2行，row_bytes含所选整行全部列；number_bytes仅归并到城市且非空、有限、非负的读数文本字节，不含逗号、时间、站号或重复派生表。逐日的两个指标有效站点小时数均与已发表的全国城市小时表相等。每月取观测日期中位一日12时复算南京、阜阳、上海的可用城市值。"}
    tag=snap.name
    daily.to_csv(HERE/(tag+"每日核验.csv"))
    pd.DataFrame([{"date":d,"city":c,"species":s,"独立复算":v,"城市小时表":observed[d,c,s]} for (d,c,s),v in sorted(samples.items())]).to_csv(HERE/(tag+"均值抽查.csv"),index=False)
    (HERE/(tag+"核验结果.json")).write_text(json.dumps(rec,ensure_ascii=False,indent=2))
    print(json.dumps(rec,ensure_ascii=False))

if __name__=="__main__":
    main()
