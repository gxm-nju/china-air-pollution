"""Resume the dated station files, validating source records before publication."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import time
import csv
import fcntl
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from threading import Lock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from collect import EXT, BASE, RAW, verified_paths, validated, sha, log

OUT = Path(__file__).resolve().parent
FREE = RAW / "air"
write_lock = Lock()


def record(state, day, **fields):
    with write_lock, (OUT / "逐次采集.jsonl").open("a", encoding="utf8") as stream:
        stream.write(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),
                                     date=day, status=state, **fields), ensure_ascii=False) + "\n")


def download(row):
    day = row["date"]
    url = row["url"]
    dest = FREE / url.rsplit("/", 1)[1]
    tmp = dest.with_suffix(".csv.new.part")
    meta = tmp.with_suffix(".headers")
    try:
        # A partial object may only be extended against the same remote entity.
        args = ["curl", "--silent", "--show-error", "--fail", "--location",
                "--connect-timeout", "18", "--max-time", "80", "--retry", "1",
                "--dump-header", str(meta.with_suffix(".next")), "--output", str(tmp)]
        if tmp.exists() and tmp.stat().st_size:
            saved = meta.read_text() if meta.exists() else ""
            tags = [s.split(":",1)[1].strip() for s in saved.splitlines() if s.lower().startswith("etag:") and not s.split(":",1)[1].strip().startswith("W/")]
            if tags:
                args += ["-C", "-", "-H", "If-Range: "+tags[-1]]
            else:
                tmp.unlink()
        probe = Path("/tmp/china_sites_20240210.csv")
        if day == "2024-02-10" and probe.exists() and not tmp.exists():
            shutil.copyfile(probe, tmp)
        else:
            result = subprocess.run(args+[url], capture_output=True, text=True)
            nextmeta = meta.with_suffix(".next")
            if nextmeta.exists() and nextmeta.stat().st_size:
                nextmeta.replace(meta)
            if result.returncode:
                if result.returncode in (33,36) or "returned error: 416" in result.stderr: tmp.unlink(missing_ok=True)
                raise ValueError(result.stderr.strip()[-350:])
        validated(tmp, "air")
        digest = sha(tmp)
        n = tmp.stat().st_size
        with write_lock:
            if dest.exists(): raise RuntimeError("concurrent target exists")
            tmp.replace(dest)
            log(status="ok", path=str(dest.relative_to(ROOT)), url=url, bytes=n, sha256=digest)
        meta.unlink(missing_ok=True)
        record("verified", day, bytes=n, sha256=digest)
    except Exception as exc:
        record("failed", day, reason=str(exc))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=3, choices=range(1,11))
    parser.add_argument("--interval", type=float, default=1.1)
    args = parser.parse_args()
    def spaced_jobs(rows):
        for row in rows:
            yield row
            time.sleep(max(0.0,args.interval))
    with (EXT / "采集.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        checks = verified_paths()
        queue = list(csv.DictReader((EXT / "跨期分析/逐日补采队列.csv").open()))
        pending = []
        for row in queue:
            name = row["url"].rsplit("/",1)[1]
            existing = [p for p in (FREE/name, BASE/"data/raw/ground"/name) if p.exists()]
            if not existing:
                pending.append(row)
            for path in existing:
                if checks.get(path) != (path.stat().st_size, sha(path)):
                    raise ValueError("Existing file disagrees with historical manifest: "+str(path))
        print("Verified existing dates",len(queue)-len(pending),"pending",len(pending),flush=True)
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(download,spaced_jobs(pending)))
        remaining = [r["date"] for r in pending if not (FREE / r["url"].rsplit("/",1)[1]).exists()]
        print("Missing after this pass", len(remaining), flush=True)
        return 1 if remaining else 0


if __name__ == "__main__":
    sys.exit(main())
