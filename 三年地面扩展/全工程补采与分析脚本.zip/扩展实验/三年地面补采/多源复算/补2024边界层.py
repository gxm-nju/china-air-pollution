"""Fill missing hourly BLH using NCSS subsets on identical ERA5 city grid points."""
import calendar
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
import hashlib
import json
import subprocess
from urllib.parse import urlencode

import numpy as np
import pandas as pd
from scipy.io import netcdf_file

OUT=Path(__file__).resolve().parent/"ERA5边界层补采"
PROJECT=OUT.parents[3]
OUT.mkdir(exist_ok=True)
meta=pd.read_csv(PROJECT/"扩展实验/多源复算/data/cleaned/era5_requested_city_grid.csv")


def extract(month):
    last=calendar.monthrange(2024,month)[1]
    start=f"2024-{month:02}-01T00:00:00Z"
    end=f"2024-{month:02}-{1 if month==7 else last:02}T23:00:00Z"
    ym=f"2024{month:02}"
    remote=f"https://tds.gdex.ucar.edu/thredds/ncss/grid/files/d633000/e5.oper.an.sfc/{ym}/e5.oper.an.sfc.128_159_blh.ll025sc.{ym}0100_{ym}{last:02}23.nc"
    params=dict(var="BLH",north=meta.latitude.max(),south=meta.latitude.min(),west=meta.longitude.min(),east=meta.longitude.max(),time_start=start,time_end=end,accept="netcdf3")
    url=remote+"?"+urlencode(params)
    path=OUT/(ym+".nc")
    fresh=not path.exists()
    source=path.with_suffix(".part") if fresh else path
    if fresh:
        subprocess.run(["curl","-fsSL","--retry","2","--connect-timeout","20","--max-time","150","-o",str(source),url],check=True)
    with netcdf_file(source,mmap=False) as f:
        v=f.variables["BLH"]
        assert v.units==b"m" and v.dimensions==("time","latitude","longitude") and f.variables["time"].units==b"hours since 1900-01-01 00:00:00"
        times=pd.Timestamp("1900-01-01")+pd.to_timedelta(f.variables["time"].data.astype(int)+8,unit="h")
        utc=pd.date_range(start,end,freq="h")
        assert len(times)==len(utc) and np.array_equal(times,utc.tz_convert(None)+pd.Timedelta(hours=8))
        lat=f.variables["latitude"].data; lon=f.variables["longitude"].data
        frames=[]
        for r in meta.itertuples():
            i=np.flatnonzero(lat==r.latitude).item();j=np.flatnonzero(lon==r.longitude).item()
            arr=v.data[:,i,j].astype(float)
            assert np.all(np.isfinite(arr)) and np.all((0 <= arr)&(arr<100000))
            frames.append(pd.DataFrame(dict(location_id=r.location_id,city=r.city,time=times,blh_gdex_m=arr)))
    if fresh: source.replace(path)
    return pd.concat(frames),dict(month=ym,url=url,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())


if __name__=="__main__":
    with ThreadPoolExecutor(max_workers=3) as pools:
        groups=list(pools.map(extract,range(1,8)))
    merged=pd.concat([g[0] for g in groups],ignore_index=True)
    pd.DataFrame([g[1] for g in groups]).to_csv(OUT/"原始区域窗口清单.csv",index=False)
    original=pd.read_csv(PROJECT/"多源数据与实验/data/raw/era5/yrd41_2023_2025.csv",skiprows=43,parse_dates=["time"])
    original.columns=["location_id","time","t2m_c","sp_hpa","ws_ms","wind_from_deg","blh_m"]
    original["blh_m"]=original.blh_m.mask(original.blh_m<=-999)
    verify=merged.merge(original[["time","location_id","blh_m"]],on=["time","location_id"],validate="one_to_one")
    assert len(verify)==len(merged)
    overlap=verify.dropna(subset="blh_m").copy()
    overlap["difference_m"]=overlap.blh_m-overlap.blh_gdex_m
    overlap.to_csv(OUT/"有值小时重叠比较.csv",index=False)
    print("overlap:",len(overlap),"median abs",overlap.difference_m.abs().median(),"max",overlap.difference_m.abs().max(),flush=True)
    f=verify[verify.blh_m.isna()].copy()
    f[["time","city","blh_gdex_m"]].to_parquet(OUT/"缺值对应城市小时.parquet",index=False)
    stats=dict(downloaded_bytes=sum(x[1]["bytes"] for x in groups),overlap=len(overlap),overlap_mae=overlap.difference_m.abs().mean(),
               overlap_max=overlap.difference_m.abs().max(),r=overlap[["blh_m","blh_gdex_m"]].corr().iloc[0,1],filled_city_hours=len(f),
               total_missing_old=int(original.blh_m.isna().sum()))
    (OUT/"验证与使用量.json").write_text(json.dumps(stats,indent=2))
    print(stats)
