"""Ground input must contain city-hours and episodes from the same cutoff."""
import argparse
import hashlib
import json
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import shapely

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT / "scripts"))
import extend_fusion as fusion

LAGS = [0, 6, 12, 24, 48]
KEY = ["time", "lat_grid", "lon_grid"]


def hash_file(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def bootstrap(wide):
    """Paired contrasts resampled by calendar day, weighted by event as in baseline."""
    rng = np.random.default_rng(20261116)
    deltas = pd.DataFrame({f"{b}h−{a}h": wide[b]-wide[a] for a,b in combinations(LAGS,2)})
    by_day = deltas.groupby(wide.index.get_level_values("time").normalize())
    sums, count = by_day.sum().to_numpy(), by_day.size().to_numpy()
    reps = []
    for _ in range(50):
        picks = rng.integers(len(count),size=(100,len(count)))
        reps.append(sums[picks].sum(axis=1)/count[picks].sum(axis=1)[:,None])
    draws = np.vstack(reps)
    mean = deltas.mean().to_numpy()
    se = draws.std(axis=0,ddof=1)
    crit = np.quantile(np.max(np.abs((draws-mean)/se),axis=1),.95)
    return pd.DataFrame(dict(pair=deltas.columns,events=len(wide),days=len(count),mean=mean,
        low=np.quantile(draws,.025,axis=0),high=np.quantile(draws,.975,axis=0),
        simultaneous_low=mean-crit*se,simultaneous_high=mean+crit*se))


def harvest(join, results):
    """Jiangsu-only regional sensitivity windows; require every fire cell in province."""
    area = pd.read_parquet(PROJECT/"扩展实验/核验/行政区面.parquet",filters=[("name","=","江苏省"),("admin_level","=","4")])
    assert len(area)==1
    province = shapely.from_wkb(area.wkb.iloc[0])
    slots = pd.read_parquet(join/"火点格中心与农田.parquet",columns=[*KEY,"lat_bin","lon_bin"])
    cells = slots[["lat_bin","lon_bin"]].drop_duplicates()
    cells["in_jiangsu"]=shapely.contains_xy(province,(cells.lon_bin+.5)/100,(cells.lat_bin+.5)/100)
    js = slots.merge(cells,on=["lat_bin","lon_bin"],validate="many_to_one").groupby(KEY).in_jiangsu.all()
    pairs = pd.read_csv(join/"fire_wind_sector_contrasts.csv.gz",parse_dates=["time"])
    same = pairs.groupby(KEY).lag.transform("nunique").eq(len(LAGS))
    common = pairs[same].copy().merge(js.rename("in_jiangsu"),on=KEY,validate="many_to_one")
    wide=common.pivot(index=KEY,columns="lag",values="delta_pm25")[LAGS]
    bootstrap(wide).to_csv(results/"配对时点差.csv",index=False)
    anchor_count = pairs.groupby(KEY).lag.nunique()
    pd.DataFrame({"valid_lags": range(1,6),
                  "events": anchor_count.value_counts().reindex(range(1,6),fill_value=0).to_numpy()}).to_csv(results/"各滞后观测可用数.csv",index=False)
    coverage = common.groupby([common.time.dt.year.rename("year"),"lag"]).agg(
        events=("delta_pm25","size"), anchor_dates=("time",lambda x:x.dt.date.nunique()),
        mean_delta=("delta_pm25","mean"), min_up=("n_up","min"),min_down=("n_down","min"),
        mean_up=("n_up","mean"), mean_down=("n_down","mean")).reset_index()
    coverage.to_csv(results/"事件城市数与年度均值.csv",index=False)
    day = common.time.dt.strftime("%m%d")
    scopes = {"全区全部月份":np.ones(len(common),dtype=bool),
              "全区6、10、11月":common.time.dt.month.isin([6,10,11]),
              "江苏麦收参考窗0521–0620":common.in_jiangsu & day.between("0521","0620"),
              "江苏秋收参考窗1001–1130":common.in_jiangsu & day.between("1001","1130")}
    rows=[]
    for name, mask in scopes.items():
        for year in [2023,2024,2025,"全期"]:
            filt=mask if year=="全期" else mask & common.time.dt.year.eq(year)
            for farm in [False,True]:
                sample=common.loc[filt & (common.n_farmland.ge(2) if farm else True)]
                for lag in LAGS:
                    z=sample[sample.lag==lag]
                    rows.append(dict(scope=name,year=year,farmland_only=farm,lag=lag,event_count=len(z),dates=z.time.dt.date.nunique(),mean=z.delta_pm25.mean()))
    pd.DataFrame(rows).to_csv(results/"收获期参考窗口.csv",index=False)
    common[common.lag==0].groupby(common.loc[common.lag==0,"time"].dt.to_period("M")).agg(
        event_count=("time","size"),anchor_days=("time",lambda x:x.dt.normalize().nunique()),
        mapped_farmland_events=("n_farmland",lambda x:(x>=2).sum())).to_csv(results/"共同锚点逐月.csv")


def main(ground_dir, output, blh_fill):
    out = output.resolve()
    ground_dir = ground_dir.resolve()
    assert out != (PROJECT/"扩展实验/多源复算").resolve()
    (out/"docs").mkdir(exist_ok=True,parents=True)
    fusion.ROOT = out
    fusion.RAW,fusion.CLEAN,fusion.JOIN,fusion.OUT=[out/p for p in ("data/raw","data/cleaned","data/integrated","results")]
    fusion.main(ground_dir,blh_fill)
    harvest(fusion.JOIN,fusion.OUT)
    frame=pd.read_parquet(fusion.JOIN/"yrd_ground_era5_hour.parquet",columns=["time","city","pm25","no2"])
    cluster=pd.read_csv(fusion.OUT/"episode_cluster.csv",parse_dates=["start","end"])
    cluster["year"]=cluster.start.dt.year
    cluster.groupby("year").agg(episodes=("city","size"),usable=("cluster","count")).to_csv(fusion.OUT/"逐年进入聚类过程数.csv")
    record=dict(ground_hours_sha256=hash_file(ground_dir/"全国城市小时.parquet"),episode_sha256=hash_file(ground_dir/"全国重污染过程.csv"),
                matched_grid_city_hours=len(frame),ground_dates=frame.time.dt.normalize().nunique(),valid_pm25_city_hours=frame.pm25.notna().sum().item(),
                valid_no2_city_hours=frame.no2.notna().sum().item())
    if blh_fill is not None:
        record["blh_fill_sha256"]=hash_file(blh_fill)
        correction=pd.read_parquet(blh_fill)
        joined=frame[["time","city"]].merge(correction,on=["time","city"],validate="one_to_one")
        record["matched_ground_hours_with_GDEX_BLH"]=len(joined)
        used = cluster.dropna(subset="cluster").reset_index(drop=True)
        events = used[["city","start","end"]].copy()
        events["time"] = [pd.date_range(a,b+pd.Timedelta(hours=23),freq="h") for a,b in zip(events.start,events.end)]
        evidence = events.explode("time").merge(correction,on=["time","city"],how="inner",validate="one_to_one")
        record["classified_episodes_with_GDEX_BLH"]=len(evidence[["city","start"]].drop_duplicates())
        record["classified_episode_hours_with_GDEX_BLH"]=len(evidence)
    (out/"运行输入.json").write_text(json.dumps(record,indent=2,ensure_ascii=False))
    results=fusion.OUT
    base=pd.read_csv(PROJECT/"扩展实验/多源复算/results/火点相同锚点对照.csv")
    extended=pd.read_csv(results/"火点相同锚点对照.csv")
    comparison=base.merge(extended,on=["scope","lag"],suffixes=("_134日","_新样本"),validate="one_to_one")
    comparison["区间宽度_134日"]=comparison.ci_high_134日-comparison.ci_low_134日
    comparison["区间宽度_新样本"]=comparison.ci_high_新样本-comparison.ci_low_新样本
    comparison.to_csv(results/"火点新旧样本对照.csv",index=False)
    contrast=pd.read_csv(results/"配对时点差.csv").merge(pd.read_csv(HERE/"原134日配对时点差.csv"),on="pair",suffixes=("_新样本","_134日"),validate="one_to_one")
    contrast.to_csv(results/"配对时点新旧样本对照.csv",index=False)
    print(json.dumps(record,ensure_ascii=False))

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("ground_dir",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--blh-fill",type=Path,help="同一ERA5网格中已核对时区及重叠日的边界层填补记录")
    args=parser.parse_args()
    main(args.ground_dir,args.output,args.blh_fill)
