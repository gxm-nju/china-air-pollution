"""Produce the release ledger, listing only CRC-checked and hash-matched regional windows."""
from pathlib import Path
import hashlib
import json
import pandas as pd

here=Path(__file__).resolve().parent
rows=[]
for p in sorted((here/'逐日凭证').glob('*.json')):
    r=json.loads(p.read_text()); dest=here/'区域日窗'/(r['day']+'.npz')
    b=dest.read_bytes()
    if len(b)!=r['regional_bytes'] or hashlib.sha256(b).hexdigest()!=r['regional_sha256']:
        raise ValueError(dest.name)
    rows.append(r)
s=pd.DataFrame(rows)
s.to_csv(here/'已核实新增日窗.csv',index=False)
s['month']=s.day.str[:6]
s.groupby('month').agg(新增日期=('day','count'),新增有效像元日=('valid_cells','sum'),区域日窗落盘字节=('regional_bytes','sum'),读取ZIP成员字节不计有效量=('transport_bytes','sum')).to_csv(here/'新增卫星逐月汇总.csv')
print(s.groupby('month').regional_bytes.agg(['count','sum']))
