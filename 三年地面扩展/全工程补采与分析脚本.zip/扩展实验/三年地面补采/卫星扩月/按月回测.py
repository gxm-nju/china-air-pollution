"""Evaluate zero-shift hourly NO2 using chronological expanding training windows."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
BASE = PROJECT/'多源数据与实验'
OLD = PROJECT/'扩展实验/多源复算'
SETS = {'仅卫星':['column_1e15'], '卫星和气象':['column_1e15','ws_ms','log_blh'],
        '卫星气象和地图':['column_1e15','ws_ms','log_blh','road_km_per_km2','industrial_area_ratio']}


def satellite_days():
    loc=pd.read_csv(BASE/'data/cleaned/case_city_grid.csv').dropna(subset='source_group').reset_index(drop=True)
    archives = sorted((BASE/'data/raw/s5p').glob('[0-9]*.npz')) + sorted((HERE/'区域日窗').glob('[0-9]'*8+'.npz'))
    if len({p.stem for p in archives})!=len(archives):raise ValueError('duplicate day')
    pieces=[]
    for p in archives:
        with np.load(p) as d:
            iy=np.abs(loc.lat.values[:,None]-d['latitude']).argmin(axis=1)
            ix=np.abs(loc.lon.values[:,None]-d['longitude']).argmin(axis=1)
            x=d['longitude'][ix];y=d['latitude'][iy]
            v=d['column'][iy,ix];n=d['observations'][iy,ix];f=d['fraction_local_day'][iy,ix]
            mask=(n>0)&np.isfinite(v)&np.isfinite(f)&(f>=0)&(f<=1)
            chunk=pd.DataFrame({'date':pd.Timestamp(p.stem),'city':loc.city,'grid_lon':x,'grid_lat':y,
                               'observations':n,'fraction_local_day':f,'column_1e15':v.astype(float)/1e15,'valid':mask})
            local_hour = pd.Series(f,index=chunk.index).where(mask).astype(float)*24+8-x/15
            chunk['time']=(chunk.date+pd.to_timedelta(local_hour,unit='h')).dt.round('h')
            pieces.append(chunk)
    return pd.concat(pieces,ignore_index=True),archives


def fit_months(usable,out):
    metrics=[];predictions=[]
    for test_month in sorted(usable.month.unique()):
        train=usable[usable.month<test_month]; test=usable[usable.month==test_month]
        if train.month.nunique()<2:continue
        for name,features in SETS.items():
            model=make_pipeline(StandardScaler(),Ridge(alpha=1.))
            model.fit(train[features],train.no2)
            predicted=model.predict(test[features])
            metrics.append(dict(month=test_month,model=name,train_first=train.date.min().date(),train_last=train.date.max().date(),
                                train_months=train.month.nunique(),n_train=len(train),n_test=len(test),test_days=test.date.nunique(),
                                test_cities=test.city.nunique(),mae=mean_absolute_error(test.no2,predicted),r2=r2_score(test.no2,predicted)))
            predictions.append(test[['date','time','city','month','no2']].assign(model=name,prediction=predicted))
    pd.DataFrame(metrics).to_csv(out/'滚动留出月指标.csv',index=False)
    pred = pd.concat(predictions,ignore_index=True)
    pred.to_parquet(out/'留出月预测明细.parquet',index=False)
    # Pair absolute errors on the same held-out city-day. One draw resamples entire observed dates.
    wide=pred.pivot(index=['month','date','city','no2'],columns='model',values='prediction').reset_index()
    wide['error_change']=(wide['卫星和气象']-wide.no2).abs()-(wide['仅卫星']-wide.no2).abs()
    rng=np.random.default_rng(20261116);comparisons=[]
    for month,g in wide.groupby('month'):
        groups=g.groupby('date').error_change.agg(['sum','size']).to_numpy()
        draws=rng.integers(0,len(groups),(3000,len(groups)))
        simulated=groups[draws,0].sum(axis=1)/groups[draws,1].sum(axis=1)
        lo,hi=np.quantile(simulated,[.025,.975])
        comparisons.append(dict(month=month,citydays=len(g),test_days=len(groups),delta_mae=g.error_change.mean(),ci_low=lo,ci_high=hi))
    pd.DataFrame(comparisons).to_csv(out/'各月加入气象的配对误差变化.csv',index=False)
    return metrics


def main(air_path,out,from_ground=False):
    out.mkdir(exist_ok=True,parents=True)
    sat,archives=satellite_days()
    ref=pd.read_csv(OLD/'data/cleaned/s5p_city_day.csv',parse_dates=['date','effective_time'])
    probe=sat.merge(ref,on=['date','city'],suffixes=('_new','_ref'),validate='one_to_one')
    assert len(probe)==len(ref) and probe.valid_new.eq(probe.valid_ref).all()
    q=probe[probe.valid_new]
    assert q.time.eq(q.effective_time.dt.round('h')).all()
    np.testing.assert_allclose(q.column_1e15_new,q.column_1e15_ref,rtol=1e-6)
    if from_ground:
        # Allows a frozen ground snapshot to be independently joined before the Q1 run.
        loc=pd.read_csv(BASE/'data/cleaned/case_city_grid.csv').dropna(subset='source_group').sort_values('city').reset_index(drop=True)
        weather_file=BASE/'data/raw/era5/yrd41_2023_2025.csv'
        meta=pd.read_csv(weather_file,nrows=len(loc))
        assert meta.utc_offset_seconds.eq(28800).all() and meta.location_id.tolist()==list(range(len(loc)))
        assert (meta.latitude-loc.lat).abs().max()<.16 and (meta.longitude-loc.lon).abs().max()<.16
        met=pd.read_csv(weather_file,skiprows=len(loc)+2,parse_dates=['time'])
        met.columns=['location_id','time','t2m_c','sp_hpa','ws_ms','wind_from_deg','blh_m']
        met['city']=met.location_id.map(loc.city)
        for c in ['ws_ms','blh_m']:met[c]=met[c].mask(met[c]<=-999)
        ground=pd.read_parquet(air_path,columns=['time','city','NO2','n_NO2'],filters=[('city','in',loc.city.tolist())]).rename(columns={'NO2':'no2','n_NO2':'no2_n'})
        ground=ground.merge(met[['time','city','ws_ms','blh_m']],on=['city','time'],validate='one_to_one')
    else:
        ground=pd.read_parquet(air_path,columns=['time','city','no2','no2_n','ws_ms','blh_m'])
    osm=pd.read_csv(BASE/'data/cleaned/osm_city_features.csv')
    sample=sat[sat.valid].merge(ground,on=['city','time'],how='left',validate='many_to_one').merge(osm,on='city',validate='many_to_one')
    sample['log_blh']=np.log1p(sample.blh_m.where(sample.blh_m.ge(0)))
    usable=sample.dropna(subset=['no2',*SETS['卫星气象和地图']]).sort_values(['date','city']).copy()
    usable['month']=usable.date.dt.to_period('M').astype(str)
    usable.to_parquet(out/'模型实际使用的城市小时.parquet',index=False)
    unique_sat=usable[['date','grid_lon','grid_lat','observations','fraction_local_day','column_1e15']].drop_duplicates()
    assert not unique_sat.duplicated(['date','grid_lon','grid_lat']).any()
    grid_path=out/'模型实际关联卫星格日去重.parquet'
    unique_sat.to_parquet(grid_path,index=False)
    metrics=fit_months(usable,out)
    cov=pd.DataFrame(index=pd.period_range('2023-01','2025-12',freq='M').astype(str))
    for name,frame in [('候选',sat),('卫星有效',sample),('有地面NO2',sample.dropna(subset=['no2'])),('全部变量有效',usable)]:
        groups=frame.groupby(frame.date.dt.strftime('%Y-%m'))
        cov[name+'城市日']=groups.size();cov[name+'日期']=groups.date.nunique()
    cov.fillna(0).astype(int).rename_axis('月份').to_csv(out/'按月样本覆盖.csv')
    research_bytes=sum(p.stat().st_size for p in archives)
    with air_path.open('rb') as f:ground_digest=hashlib.file_digest(f,'sha256').hexdigest()
    log=dict(air_input=str(air_path),ground_only_input=from_ground,air_sha256=ground_digest,regional_days=len(archives),regional_bytes=research_bytes,
             unique_matched_city_days=len(usable),matched_dates=usable.date.nunique(),tested_months=len({r['month'] for r in metrics}),
             validated_pilot_city_days=len(probe), used_satellite_grid_days=len(unique_sat), used_grid_table_bytes=grid_path.stat().st_size)
    (out/'运行记录.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
    print(log)
    print(pd.DataFrame(metrics).pivot(index='month',columns='model',values='mae').round(3))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('air_path',type=Path,help='新地面与ERA5融合的长三角城市小时表')
    parser.add_argument('--ground',action='store_true',help='输入全国地面小时表，并独立连接原始气象文件')
    parser.add_argument('--out',type=Path,default=HERE/'滚动留出')
    parser.add_argument('--replay',action='store_true',help='由已发布的模型城市小时明细直接重训，无需联网')
    args=parser.parse_args()
    if args.replay:
        data=pd.read_parquet(args.air_path)
        args.out.mkdir(parents=True,exist_ok=True)
        fit_months(data,args.out)
    else:
        main(args.air_path,args.out,args.ground)
