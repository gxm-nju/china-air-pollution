"""Extract research windows from independently checked ZIP members using HTTPS ranges."""
import argparse
import binascii
import concurrent.futures
import hashlib
import io
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import tempfile
import threading
import zipfile
import zlib

import h5py
import numpy as np

HERE = Path(__file__).resolve().parent
RAW = HERE / '区域日窗'
RECEIPTS = HERE / '逐日凭证'
FIELDS = {
    'column': 'tropospheric_NO2_column_number_density',
    'observations': 'no_observations',
    'cloud': 'cloud_radiance_fraction',
    'fraction_local_day': 'eff_frac_day',
    'uncertainty': 'tropospheric_NO2_column_number_density_total_uncertainty',
}
URL = 'https://d1qb6yzwaaq4he.cloudfront.net/airpollution/no2col/cci-no2/tropomi/2023/ESACCI-PREC-L3C-NO2-S5P_TROPOMI_KNMI-0360x0720_1D-{}-fv2.0.zip'
LOCK = threading.Lock()


def fetch(url, span, tag=None):
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / 'data'
        headers = Path(tmp) / 'headers'
        cmd = ['curl','--fail','--silent','--show-error','--location','--retry','2',
               '--connect-timeout','25','--max-time','240','-r',span,'-D',str(headers),'-o',str(path)]
        if tag:
            cmd += ['-H', 'If-Match: '+tag]
        ret = subprocess.run(cmd+[url],capture_output=True,text=True)
        if ret.returncode:
            raise RuntimeError(ret.stderr.strip())
        hdr = headers.read_text()
        interval = re.findall(r'(?im)^content-range:\s*bytes (\d+)-(\d+)/(\d+)',hdr)
        tags = re.findall(r'(?im)^etag:\s*([^\s]+)',hdr)
        if not interval or not tags or (tag and tag!=tags[-1]): raise RuntimeError('Missing Content-Range or ETag')
        start,end,total = map(int,interval[-1])
        if not span.startswith('-') and span!=f'{start}-{end}': raise RuntimeError(f'Wrong byte range {span}: {interval[-1]}')
        if span.startswith('-') and (end+1!=total or start!=max(total-int(span[1:]),0)): raise ValueError('Wrong ZIP tail')
        data = path.read_bytes()
        if len(data)!=end-start+1: raise RuntimeError('Truncated response')
        return data,tags[-1],total


def directory(month):
    url = URL.format(month)
    data,tag,total = fetch(url,'-65536')
    # Python's ZIP reader adjusts offsets to the partial stream. Add the tail's offset to recover absolute positions.
    listing = []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        members = sorted(archive.infolist(),key=lambda m:m.header_offset)
        for index,member in enumerate(members):
            if not member.filename.endswith('.nc'): continue
            day = re.search(r'1D-(\d{8})-fv2.0.nc$',member.filename)[1]
            start = member.header_offset + total-len(data)
            end = start+30+len(member.filename.encode())+len(member.extra)+member.compress_size+512
            if index+1<len(members): end = members[index+1].header_offset+total-len(data)
            listing.append(dict(day=day,member=member.filename,url=url,start=start,end=min(end,total)-1,etag=tag,
                                compressed=member.compress_size,crc=member.CRC,method=member.compress_type))
    return listing


def extract(row):
    day = row['day'];dest=RAW/(day+'.npz');proof=RECEIPTS/(day+'.json')
    if dest.exists() and proof.exists():
        old=json.loads(proof.read_text())
        if old['etag']==row['etag'] and hashlib.sha256(dest.read_bytes()).hexdigest()==old['regional_sha256']:
            return 'reused'
        raise ValueError('Existing proof mismatch '+day)
    span=f"{row['start']}-{row['end']}"
    block,_,_ = fetch(row['url'],span,row['etag'])
    head=struct.unpack_from('<IHHHHHIIIHH',block)
    if head[0]!=0x04034b50 or head[3]!=8 or block[30:30+head[-2]].decode()!=row['member']: raise ValueError('Inconsistent ZIP local header')
    offset=30+sum(head[-2:]);nc=zlib.decompress(block[offset:offset+row['compressed']],-15)
    if binascii.crc32(nc)!=row['crc']:raise ValueError('CRC mismatch')
    with h5py.File(io.BytesIO(nc)) as h:
        lat=h['latitude'][:] if 'latitude' in h else h['lat'][:]
        lon=h['longitude'][:] if 'longitude' in h else h['lon'][:]
        iy=np.flatnonzero((lat>=20)&(lat<42));ix=np.flatnonzero((lon>=105)&(lon<125))
        assert len(iy)==44 and len(ix)==40 and np.all(np.diff(ix)==1) and np.all(np.diff(iy)==1)
        y=lat[iy];x=lon[ix]
        vals={'latitude':np.sort(y)[::-1],'longitude':x}
        for key,name in FIELDS.items():
            dataset=h[name]
            sl=(slice(iy[0],iy[-1]+1),slice(ix[0],ix[-1]+1))
            a=dataset[sl if dataset.ndim==2 else (0,*sl)]
            fill=dataset.attrs.get('_FillValue')
            if fill is not None:
                vv=float(np.asarray(fill).ravel()[0])
                a=np.where(a==vv,0 if key=='observations' else np.nan,a)
            scale=float(np.asarray(dataset.attrs.get('scale_factor',[1])).ravel()[0])
            add=float(np.asarray(dataset.attrs.get('add_offset',[0])).ravel()[0])
            a=a*scale+add
            vals[key]=(a[::-1] if y[0]<y[-1] else a).astype('int32' if key=='observations' else 'float32')
    assert np.allclose(vals['longitude'],np.arange(105.25,125,.5)) and np.allclose(vals['latitude'],np.arange(41.75,20,-.5))
    temp=dest.with_suffix('.part.npz');np.savez_compressed(temp,**vals)
    data=temp.read_bytes()
    receipt=dict(**row,netcdf_sha256=hashlib.sha256(nc).hexdigest(),transport_bytes=len(block),
                 regional_bytes=len(data),regional_sha256=hashlib.sha256(data).hexdigest(),
                 valid_cells=int(((vals['observations']>0)&np.isfinite(vals['column'])).sum()))
    os.replace(temp,dest)
    part=proof.with_suffix('.part');part.write_text(json.dumps(receipt,ensure_ascii=False));os.replace(part,proof)
    return 'ok'


def main(args):
    RAW.mkdir(exist_ok=True);RECEIPTS.mkdir(exist_ok=True)
    jobs=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for m,listing in zip(args.months,pool.map(directory,args.months)):
            print(m,'remote days',len(listing),flush=True);jobs+=listing
    jobs.sort(key=lambda row:(int(row['day'][6:])%7!=1,row['day'][6:],row['day']))
    if args.weekly: jobs=[r for r in jobs if int(r['day'][6:])%7==1]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(extract,row):row['day'] for row in jobs}
        fails=0
        for future in concurrent.futures.as_completed(futures):
            try:state=future.result()
            except Exception as exc:state=repr(exc);fails+=1
            print(futures[future],state,flush=True)
    if fails:raise SystemExit(f'{fails} failed dates')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('months',nargs='+')
    parser.add_argument('--workers',type=int,default=5)
    parser.add_argument('--weekly',action='store_true')
    main(parser.parse_args())
