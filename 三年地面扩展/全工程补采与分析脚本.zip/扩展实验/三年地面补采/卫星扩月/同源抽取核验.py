"""Cross-check the HDF5 window against one previously GDAL-extracted day."""
import importlib.util
import tempfile
from pathlib import Path
import numpy as np
import json
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fetch',here/'采集日窗.py')
fetch=importlib.util.module_from_spec(spec);spec.loader.exec_module(fetch)
row=fetch.directory('202303')[0];day=row['day']
with tempfile.TemporaryDirectory() as tmp:
    fetch.RAW=Path(tmp);fetch.RECEIPTS=Path(tmp)
    fetch.extract(row)
    new_file=Path(tmp)/(day+'.npz')
    old_file=here.parents[2]/'多源数据与实验/data/raw/s5p'/(day+'.npz')
    with np.load(new_file) as new,np.load(old_file) as old:
        common=(old['observations']>0)&np.isfinite(old['column'])
        rebuilt=(new['observations']>0)&np.isfinite(new['column'])
        np.testing.assert_array_equal(rebuilt,common)
        for coord in ['latitude','longitude']:np.testing.assert_array_equal(new[coord],old[coord])
        fields={}
        for field in fetch.FIELDS:
            x=new[field][common];y=old[field][common]
            np.testing.assert_allclose(x,y,rtol=1e-7,atol=1e-7,equal_nan=True)
            fields[field]=float(np.nanmax(np.abs(x.astype(float)-y.astype(float))))
    receipt=json.loads((Path(tmp)/(day+'.json')).read_text())
    (here/'抽取程序重叠日核对.json').write_text(json.dumps(dict(day=day,member_sha256=receipt['netcdf_sha256'],valid_cells=int(common.sum()),differences=fields),ensure_ascii=False,indent=2))
