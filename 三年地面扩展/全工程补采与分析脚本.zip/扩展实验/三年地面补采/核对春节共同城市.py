"""Compare the same cities across all dates in the three windows of each year."""
from pathlib import Path
import argparse

import pandas as pd


def compare(folder):
    days = pd.read_parquet(folder / '全国城市日.parquet')
    valid = days[days.yrd41 & days.qualified][['city','date','pm25','heavy']].copy()
    windows = pd.read_csv(folder / '春节比较.csv', parse_dates=['起','止'])
    rows = []
    for year, group in windows.groupby('年'):
        expected = sum((r.止-r.起).days+1 for r in group.itertuples())
        block = valid[valid.date.between(group.起.min(), group.止.max())]
        counts = block.groupby('city').date.nunique()
        same = block[block.city.isin(counts[counts.eq(expected)].index)]
        for win in group.itertuples():
            part = same[same.date.between(win.起, win.止)]
            rows.append({'年':year,'窗口':win.窗口,'起':win.起.date(),'止':win.止.date(),
                         '共同城市数':part.city.nunique(),'城市日数':len(part),
                         '平均PM25':part.pm25.mean(),'超过150的城市日':int(part.heavy.sum()) if len(part) else None})
    pd.DataFrame(rows).to_csv(folder/'春节三窗口共同城市.csv',index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('folder',type=Path)
    compare(parser.parse_args().folder)
